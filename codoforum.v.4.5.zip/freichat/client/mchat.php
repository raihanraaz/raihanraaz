<?php
if (!isset($_GET['id']) || !isset($_GET['xhash']))
    exit;

require '../arg.php';

$FC = new FreiChat();

$FC->init_vars();
$frei_trans = $FC->frei_trans;
$url = $FC->url;

if (isset($_SERVER['HTTP_REFERER'])) {
    $referer_url = $_SERVER['HTTP_REFERER'];
} else {
    $referer_url = $url;
}


if (strpos($referer_url, 'www.') == TRUE) {
    $url = str_replace('http://', 'http://www.', $url);
    $url = str_replace('https://', 'https://www.', $url);
} else {

    $url = str_replace('http://www.', 'http://', $url);
    $url = str_replace('https://www.', 'https://', $url);
}

if (strpos($url, 'www.www.') == TRUE) {
    $url = str_replace('http://www.www.', 'http://www.', $url);
    $url = str_replace('https://www.www.', 'https://www.', $url);
}


$id = strip_tags($_GET['id']);
$xhash = strip_tags($_GET['xhash']);

$url = str_replace("mchat.php", "", $url);
?>


<!DOCTYPE html>
<html>
    <head>
        <title>Chat</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
<!--        <base href="--><?php //echo $url; ?><!--m/dist/" target="_blank">-->
        <script src="<?php echo $url; ?>main.php?id=<?php echo $id; ?>&xhash=<?php echo $xhash; ?>&mobile=1" type="text/javascript"></script>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.5.1/css/bulma.min.css">
        <script>
            FreiChat.init();
        </script>
    </head>
    <body>
    <div id="root" style="height: 100%">
    </div>
    <script type="text/javascript" src="m/public/bundle.js"></script>
    </body>
</html>