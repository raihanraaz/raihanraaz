<?php
/**
 * (c) Codologic Software Pvt. Ltd.
 * User: silva
 */

$lang = 'english';

if(isset($_GET['lang'])){
    $lang = preg_replace("/[^A-Za-z0-9_]/", '', $_GET['lang']);
}

if (is_file('../lang/'.$lang.'.php')){
    header('Content-Type: application/json');
    require '../lang/'.$lang.'.php';
    echo json_encode($frei_trans);
}else{
    die("lang file not found: " . $lang );
}
