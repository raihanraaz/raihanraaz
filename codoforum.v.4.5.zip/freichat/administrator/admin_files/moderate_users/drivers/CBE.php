<?php

require 'Joomla.php';

class CBE extends Joomla {
    
    public function __construct() {
        
    }
} 
