<?php

require 'base.php';

class Codoforum extends driver_base
{

    public function __construct($db)
    {
        //parent::__construct();
        $this->db = $db;
    }

//------------------------------------------------------------------------------
    public function getDBdata($session_id, $first)
    {
        if ($session_id == 0) {
            $_SESSION[$this->uid . 'is_guest'] = 1;
        } else {
            $_SESSION[$this->uid . 'is_guest'] = 0;
        }
        if ($_SESSION[$this->uid . 'is_guest'] == 0) {
            if ($_SESSION[$this->uid . 'time'] < $this->online_time || isset($_SESSION[$this->uid . 'usr_name']) == false || $first == 'false') { //To consume less resources , now the query is made only once in 15 seconds
                $query = "SELECT DISTINCT u.id, u.name
                      FROM " . DBprefix . "codo_users AS u
                      WHERE u.id = ?  LIMIT 1";

                $res_obj = $this->db->prepare($query);
                $res_obj->execute(array($session_id));
                $res = $res_obj->fetchAll();

                if ($res == null) {
                    $this->freichat_debug("Incorrect Query :  " . $query . " \n session id:  " . $session_id . "\n PDO error: " . print_r($this->db->errorInfo(), true));
                }

                foreach ($res as $result) {
                    if (isset($result['name'])) { //To avoid undefined index error. Because empty results were shown sometimes
                        $_SESSION[$this->uid . 'usr_name'] = $result['name'];
                        $_SESSION[$this->uid . 'usr_ses_id'] = $session_id;
                    }
                }
            }
        } else {
            $_SESSION[$this->uid . 'usr_name'] = $_SESSION[$this->uid . 'gst_nam'];
            $_SESSION[$this->uid . 'usr_ses_id'] = $_SESSION[$this->uid . 'gst_ses_id'];
        }
    }

//------------------------------------------------------------------------------
    public function getList()
    {

        $user_list = null;

        if ($this->show_name == 'guest') {
            $user_list = $this->get_guests();
        } else if ($this->show_name == 'user') {
            $user_list = $this->get_users();
        } else {
            $this->freichat_debug('USER parameters for show_name are wrong.');
        }
        return $user_list;
    }
//------------------------------------------------------------------------------

    /**
     *  Used to get users that can be added to a group chat
     */
    public function search_users($keyword = '')
    {

        $arr = array();
        $searchCondition = "";
        if ($keyword != '') {
            $arr = array(":word" => "$keyword%");
            $searchCondition = 'AND u.name LIKE :word';
        }

        $qry = 'SELECT distinct u.avatar, u.name AS username, u.id AS userid, f.status
                FROM ' . DBprefix . 'codo_users AS u'
            . ' LEFT JOIN frei_session AS f ON u.id=f.session_id'
            . ' WHERE u.mail<>\'anonymous@localhost\' ' . $searchCondition;

        $stmt = $this->db->prepare($qry);
        $stmt->execute($arr);

        return $stmt->fetchAll();

    }

//------------------------------------------------------------------------------
    public function getConversationList()
    {

        $frm_id = $_SESSION[$this->uid . 'usr_ses_id'];

        $conversations = array();
        $res = $this->db->query("SELECT conv.id as conv_id, cu.avatar, MAX(conv.message_time) as msg_time, 
                                  cu.name AS username, conv.message, cu.id as userid 
                                FROM frei_conversations as conv
                                INNER JOIN codo_users cu on cu.id = conv.pm_uid
                                WHERE conv.uid=$frm_id 
                                GROUP by pm_uid");

        if ($res) {
            $conversations = $res->fetchAll();
        }

        return $conversations;
    }
//------------------------------------------------------------------------------
    public function avatar_url($res) {

        $avatar = $res['avatar'];

        if(strpos($avatar, '//') !== FALSE)
            return $avatar;

        $murl = str_replace("freichat/", "", $this->url);
        $dir = $murl . 'sites/default/assets/img/profiles/icons/';
        return $dir . $res['avatar'];
    }

//------------------------------------------------------------------------------
    public function load_driver()
    {
        //define("DBprefix", $this->db_prefix);
        $session_id = $this->options['id'];
        $custom_mesg = $this->options['custom_mesg'];
        $first = $this->options['first'];

// 1. Connect The DB
//      DONE
// 2. Basic Build the blocks
        $this->createFreiChatXsession();
// 3. Get Required Data from client DB
        $this->getDBdata($session_id, $first);
        $this->check_ban();
// 4. Insert user data in FreiChatX Table Or Recreate Him if necessary
        $this->createFreiChatXdb();
// 5. Update user data in FreiChatX Table
        $this->updateFreiChatXdb($first, $custom_mesg);
// 6. Delete user data in FreiChatX Table
        $this->deleteFreiChatXdb();
// 7. Get Appropriate UserData from FreiChatX Table
        if ($this->usr_list_wanted == true) {
            $result = $this->getList();
            return $result;
        }
// 8. Send The final Data back
        return true;
    }

}