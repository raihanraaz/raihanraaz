<?php

class chatroom extends Conn {

    
    public function __construct() {
        parent::__construct();
    }
}